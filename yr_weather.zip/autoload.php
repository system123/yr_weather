<?php

$namespace = plugin_dir_path(__FILE__) . DIRECTORY_SEPARATOR . "Yr" . DIRECTORY_SEPARATOR;

include $namespace . "Yr.php";
include $namespace . "Location.php";
include $namespace . "Forecast.php";
include $namespace . "TextualForecast.php";
include $namespace . "WeatherStation.php";

require_once dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'wpcloudy-anim.php';